package com.example.codexalters.network

import com.example.codexalters.apimodel.EmployeeList
import com.example.codexalters.commonclass.CommonValues
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface ApiService {

    @GET(CommonValues.ENDPOINT)
    fun getEmployeesList():Call<EmployeeList>

    companion object{
        private var Instance:ApiService? = null
        fun getInstance():ApiService{
            if (Instance == null){
                val retrofitservice = Retrofit.Builder()
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(CommonValues.BASE_URL)
                    .build()
                Instance = retrofitservice.create(ApiService::class.java)
            }
            return Instance!!
        }
    }

}