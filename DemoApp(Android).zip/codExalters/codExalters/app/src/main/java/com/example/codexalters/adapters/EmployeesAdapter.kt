package com.example.codexalters.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.codexalters.apimodel.Data
import com.example.codexalters.databinding.EmployeelistItemrowBinding

class EmployeesAdapter(private val context: Context,var emplList:onItemClick ):RecyclerView.Adapter<EmployeesAdapter.MyViewHolder>() {

    var empList = mutableListOf<Data>()

    fun empDetails(data: ArrayList<Data>){
        this.empList = data
        notifyDataSetChanged()
    }

    class MyViewHolder(val binding: EmployeelistItemrowBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(EmployeelistItemrowBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val employeeList = empList[position]

        Glide.with(context).load(employeeList.image).into(holder.binding.imgViewEmployeeImage)
        holder.binding.tvEmployeeName.text = employeeList.name
        holder.binding.tvTechnology.text = employeeList.technology
        holder.binding.tvEmployeeEmail.text = employeeList.emp_Id
        holder.binding.tvEmployeeMobile.text = employeeList.mobile_no
        holder.binding.tvEmployeeAddress.text = employeeList.address

        holder.itemView.setOnClickListener {
            emplList.onItemClickListner(employeeList)
        }
    }

    override fun getItemCount(): Int {
        return empList.size
    }

    interface onItemClick{
        fun onItemClickListner(employeedata:Data)
    }
}