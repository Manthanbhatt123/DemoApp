package com.example.codexalters.apimodel

data class EmployeeList(
    val `data`: List<Data>,
    val message: String,
    val statusCode: Int
)