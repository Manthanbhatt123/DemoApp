package com.example.codexalters.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.codexalters.apimodel.Data
import com.example.codexalters.apimodel.EmployeeList
import com.example.codexalters.repository.MainRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val repository: MainRepository):ViewModel() {
    val employeeList = MutableLiveData<ArrayList<Data>>()

    fun getEmployeeList(){
        val response = repository.getEmployeeData()

        response.enqueue(object : Callback<EmployeeList>{
            override fun onResponse(call: Call<EmployeeList>, response: Response<EmployeeList>) {
                employeeList.postValue(response.body()?.data as ArrayList<Data>)
            }
            override fun onFailure(call: Call<EmployeeList>, t: Throwable) {
                Log.d("Failure", "onFailure: ${t.message}")
            }

        })
    }
}