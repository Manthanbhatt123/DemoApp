package com.example.codexalters.activities.activities.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.codexalters.adapters.EmployeesAdapter
import com.example.codexalters.apimodel.Data
import com.example.codexalters.databinding.ActivityMainBinding
import com.example.codexalters.network.ApiService
import com.example.codexalters.repository.MainRepository
import com.example.codexalters.viewmodel.MainViewModel
import com.example.codexalters.viewmodel.ViewModelFactory

class MainActivity : AppCompatActivity(),EmployeesAdapter.onItemClick {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: EmployeesAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
    }

    private fun init(){
        initAdapter()
        initViewModel()
    }

    private fun initAdapter(){
        adapter = EmployeesAdapter(this,this)
        binding.rvEmployeeList.adapter = adapter
        binding.rvEmployeeList.layoutManager = LinearLayoutManager(this)
    }

    private fun initViewModel(){
        val repository = ApiService.getInstance()
        viewModel = ViewModelProvider(this,ViewModelFactory(MainRepository(repository))).get(MainViewModel::class.java)
        viewModel.getEmployeeList()
        viewModel.employeeList.observe(this, Observer {
            adapter.empDetails(it!!)
        })
    }

    override fun onItemClickListner(employeedata: Data) {
        val i = Intent(this,DisplayEmployeesDetails::class.java)
        i.putExtra("Image",employeedata.image)
        i.putExtra("Name",employeedata.name)
        i.putExtra("Technology",employeedata.technology)
        i.putExtra("Email",employeedata.emp_Id)
        i.putExtra("Mobile",employeedata.mobile_no)
        i.putExtra("Address",employeedata.address)
        startActivity(i)
    }
}