package com.example.codexalters.activities.activities.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.codexalters.databinding.ActivityDisplayEmployeesDetailsBinding

class DisplayEmployeesDetails : AppCompatActivity() {
    private lateinit var binding: ActivityDisplayEmployeesDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayEmployeesDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    fun init(){
        getApiData()
        onclick()
    }

    fun getApiData(){
        val image =intent.getStringExtra("Image")
        val name = intent.getStringExtra("Name")
        val technology = intent.getStringExtra("Technology")
        val email = intent.getStringExtra("Email")
        val mobile = intent.getStringExtra("Mobile")
        val address = intent.getStringExtra("Address")


        Glide.with(this).load(image).into(binding.imgViewEmployeeImageDisplay)
        binding.tvEmployeeNameDisplay.text = name
        binding.tvTechnologyDisplay.text = technology
        binding.tvEmployeeEmailDisplay.text = email
        binding.tvEmployeeMobileDisplay.text = mobile
        binding.tvEmployeeAddressDisplay.text = address

    }

    fun onclick(){
        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}