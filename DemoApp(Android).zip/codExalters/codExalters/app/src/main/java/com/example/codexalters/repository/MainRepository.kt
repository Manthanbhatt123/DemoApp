package com.example.codexalters.repository

import com.example.codexalters.network.ApiService

class MainRepository(private val apiService: ApiService) {
    fun getEmployeeData() = apiService.getEmployeesList()
}