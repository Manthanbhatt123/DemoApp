package com.example.codexalters.commonclass

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


//url=http://codexalters-techlabs.com/employee/getEmployeeList.php

object CommonValues {
    const val BASE_URL = "http://codexalters-techlabs.com/"
    const val ENDPOINT = "employee/getEmployeeList.php"
}